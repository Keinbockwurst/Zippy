**************************************************
* Formhandler - Basic Examples - Disable Submit **
**************************************************

This example shows how to disable the submit button until all fields are filled out correclty. 
After the user submitted the form, an email gets sent to an administrator.

* Include the TypoScript in the folder "ts".
* Configure the path to the files and other settings using the TypoScript Constant Editor.

**********************
****** Example *******
**********************

<INCLUDE_TYPOSCRIPT: source="FILE: fileadmin/formhandler/basic-examples/disable-submit/ts/ts_setup.txt">
